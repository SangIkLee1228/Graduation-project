# HotelRec 데이터셋 분석 프로젝트

47GB 단일 JSON 파일을 Windows 환경(VS Code + 터미널)에서 분석하기 위한 스크립트 모음.

## 📁 폴더 구조
```
hotelrec_project/
├── data/                    # HotelRec.txt 원본 파일 위치
├── output/                  # 샘플·통계·전처리 결과 저장
├── scripts/
│   ├── 01_peek.py           # 앞 N건만 미리보기
│   ├── 02_validate.py       # 전체 파일 검증 통계
│   ├── 03_sample.py         # Reservoir Sampling으로 랜덤 샘플 추출
│   ├── 04_filter_parquet.py # 조건 필터링 후 Parquet 저장
│   └── 05_eda.py            # 샘플 기반 탐색적 데이터 분석
├── requirements.txt
└── README.md
```

## 🔧 사전 준비 (1회만)

### 1. Python 설치 확인
PowerShell 또는 cmd에서:
```powershell
python --version
```
3.9 이상 필요. 없다면 https://www.python.org/downloads/ 에서 설치 (설치 시 "Add Python to PATH" 체크).

### 2. VS Code 준비
- VS Code 설치: https://code.visualstudio.com/
- 확장 프로그램 설치: **Python** (Microsoft), **Jupyter**, **Rainbow CSV** (선택)

### 3. 프로젝트 폴더 열기
```powershell
cd C:\path\to\hotelrec_project
code .
```

### 4. 가상환경 생성 & 활성화
VS Code 터미널 (Ctrl + `) 에서:
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

> 만약 **"실행 정책" 오류**가 나면, 관리자 권한 PowerShell에서 한 번만:
> ```powershell
> Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
> ```

활성화되면 프롬프트 앞에 `(venv)`가 표시됩니다.

### 5. 패키지 설치
```powershell
pip install -r requirements.txt
```

### 6. 데이터 다운로드
https://drive.switch.ch/index.php/s/n48smsdufhRA7fR 에서 받은
`HotelRec.txt`를 `data/` 폴더에 넣습니다.

## ▶️ 실행 순서

> 모든 명령은 VS Code 터미널(가상환경 활성화 상태)에서 실행.

### Step 1 — 미리보기 (수 초)
```powershell
python scripts/01_peek.py
```
앞 100건만 읽어 스키마, 키 종류, 샘플을 출력합니다.

### Step 2 — 전체 검증 (수 분 ~ 수십 분)
```powershell
python scripts/02_validate.py
```
파일 전체를 한 줄씩 스트리밍하며 결측값, 평점 분포, 파싱 오류 등을 집계해
`output/validation_stats.json`에 저장합니다.

### Step 3 — 샘플 추출 (수 분)
```powershell
python scripts/03_sample.py --k 100000
```
Reservoir Sampling으로 100k(기본) 균등 랜덤 샘플을 추출해
`output/sample_100k.jsonl`로 저장. `--k` 인자로 크기 조절 가능.

### Step 4 — 조건 필터링 + Parquet 변환 (수십 분)
```powershell
python scripts/04_filter_parquet.py
```
텍스트 길이·평점 유무 등 조건을 만족하는 레코드만 골라
`output/hotelrec_filtered.parquet`로 저장.
Parquet은 원본보다 5~10배 작고 빠르게 로드됩니다.

### Step 5 — EDA (즉시)
```powershell
python scripts/05_eda.py
```
Step 3에서 추출한 샘플로 기본 통계와 분포 차트를 그려
`output/`에 PNG로 저장.

> 또는 VS Code에서 `.ipynb` 파일을 새로 만들어 셀 단위로 실험해도 좋습니다.

## 💡 자주 마주치는 문제

| 증상 | 원인 / 해결 |
|------|------------|
| `FileNotFoundError: HotelRec.txt` | `data/` 폴더에 파일이 있는지 확인, 경로 슬래시 방향 무관 |
| `JSONDecodeError` 다수 발생 | 정상. 첫·마지막 줄의 `[`, `]`나 끝 콤마 때문. 스크립트가 처리함 |
| 메모리 부족 | 모든 스크립트는 스트리밍 처리라 RAM 영향 없음. pandas로 전체 로드는 금지 |
| 인코딩 오류 | 모든 파일을 `encoding='utf-8'`로 열고 있음. 변경 금지 |
| `pip install` 매우 느림 | 미러 사용: `pip install -r requirements.txt -i https://pypi.org/simple` |
